var mySwiper = new Swiper ('.swiper-head', {
				direction: 'horizontal', // 垂直切换选项
				loop: true, // 循环模式选项
				autoplay: {
				delay: 2500,	//2.5秒切换一次
				disableOnInteraction: false,	
				},
				// 如果需要分页器
				pagination: {
					el: '.swiper-pagination',
					clickable :true,
				},
			  // 如果需要前进后退按钮
				navigation: {
					nextEl: '.swiper-button-next',
					prevEl: '.swiper-button-prev',
				},
			 })
 var swiper = new Swiper('.swiper-teacher', {
 				autoplay: {
				delay: 5000,	//2.5秒切换一次
				disableOnInteraction: false,	
				},
				slidesPerView: 5,
				slidesPerGroup : 5,
			 	spaceBetween: 30,
				pagination: {
				el: '.swiper-pagination',
				clickable: true,
				},
				navigation: {
					nextEl: '.swiper-button-next',
					prevEl: '.swiper-button-prev',
				},
			});